<!doctype html>
<html lang="es" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="San Juan – Sistema de Venta de Medicamentos">
  <title>FARM SJB | <?php echo $__env->yieldContent('title'); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
</head>

<body>

<div id="app-wrapper" class="d-flex">

  <!-- sidebar -->
  <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <div class="main-wrapper d-flex flex-column flex-grow-1 overflow-hidden">
    <!-- header -->
  <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="app-content flex-grow-1 overflow-y-auto p-3 p-lg-4">
      <div class="container-fluid p-0">
        <div class="d-flex align-items-center justify-content-between flex-column flex-sm-row gap-2 mb-4">

          <p class="text-secondary mb-0"><?php echo $__env->yieldContent('descripcion'); ?></p>

          <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="Ruta de navegación">
            <ol class="breadcrumb mb-0 small">
              <li class="breadcrumb-item">
                  <span><?php echo $__env->yieldContent('item-breadcrumb'); ?></span>
              </li>
               <li class="breadcrumb-item text-muted fw-medium" aria-current="page">
                <a href="" class="text-decoration-none text-secondary d-flex align-items-center gap-1">
                  <?php echo $__env->yieldContent('section-breadcrumb'); ?>
                </a>
              </li>
              <li class="breadcrumb-item">
                <span class="text-secondary"> <?php echo $__env->yieldContent('module-breadcrumb'); ?></span>
              </li>
            </ol>
          </nav>
        </div>


        <!-- 
            CONTENIDO DE LA VISTA
            Aquí va el contenido específico de cada página
            (KPIs, gráficos, tablas, formularios, etc.)
            En Laravel: 
        -->
            <?php echo $__env->yieldContent('content'); ?>
      </div>
    </main>

  </div>
</div>

<!-- MODAL — Confirmar Cierre de Sesión -->
<?php echo $__env->make('partials.modal-logout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>


</body>
</html>
<?php /**PATH C:\laragon\www\Farmacia\sistema\resources\views/template/administrador.blade.php ENDPATH**/ ?>