<?php $__env->startSection('title', 'CATEGORIAS'); ?>
<?php $__env->startSection('name-section', 'CATEGORIAS'); ?>

<?php $__env->startSection('description', 'Nuevo registro de categoria'); ?>
<?php $__env->startSection('item-breadcrumb', 'Inicio'); ?>
<?php $__env->startSection('section-breadcrumb', 'Categorías'); ?>
<?php $__env->startSection('module-breadcrumb', 'Configuraciones'); ?>


<?php $__env->startSection('content'); ?>
<div class="card bg-white border-0 shadow-sm border-5 border-top border-secondary">
                <div class="card-body">
                    <form action="<?php echo e(route(categories.store)); ?>" method="POST">
                    
                    <?php echo csrf_field(); ?>
                    @incude('settings.categories._form')
                    </form>
                </div>
            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.administrador', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Farmacia\sistema\resources\views/settings/categories/create.blade.php ENDPATH**/ ?>